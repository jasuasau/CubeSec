# CubeSecC2

## Boot

# install deps
pip install pycryptodomex netifaces pyperclip requests

# run
cd villain
python3 Villain2.py

## Expected Boot up

[Info] Initializing required services:
[0.0.0.0:6501]::Team Server
[0.0.0.0:4443]::Reverse TCP Multi-Handler
[0.0.0.0:8080]::HoaxShell Multi-Handler
[0.0.0.0:8888]::HTTP File Smuggler

[Info] Welcome! Type "help" to list available commands.
Villain >
