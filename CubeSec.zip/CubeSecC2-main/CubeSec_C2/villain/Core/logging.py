#!/usr/bin/env python3
#
# Author: Panagiotis Chartas (t3l3machus)
#
# This script is part of the "Villain C2 Framework":
# https://github.com/t3l3machus/Villain

import os
import json
import threading
from .common import system_type
from .settings import Logging_Settings

main_meta_folder = Logging_Settings.main_meta_folder_unix if system_type in ['Linux', 'Darwin'] else Logging_Settings.main_meta_folder_windows


class HoaxShell_Implants_Logger:

    generated_implants_file = f'{main_meta_folder}/hoaxshell_generated_implants.txt'
    _file_lock = threading.Lock()

    @staticmethod
    def store_session_details(id, session_meta):
        with HoaxShell_Implants_Logger._file_lock:
            try:
                with open(HoaxShell_Implants_Logger.generated_implants_file, 'a') as f:
                    f.write(json.dumps({"id": id, "meta": session_meta}) + '\n')
            except Exception:
                pass

    @staticmethod
    def retrieve_past_sessions_data():
        if not os.path.exists(HoaxShell_Implants_Logger.generated_implants_file):
            return False

        sessions = {}
        with HoaxShell_Implants_Logger._file_lock:
            try:
                with open(HoaxShell_Implants_Logger.generated_implants_file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            rec = json.loads(line)
                            if isinstance(rec, dict) and 'id' in rec and 'meta' in rec:
                                sessions[rec['id']] = rec['meta']
                        except Exception:
                            continue
            except Exception:
                return False

        return sessions if sessions else False


def clear_metadata():
    try:
        if os.path.exists(HoaxShell_Implants_Logger.generated_implants_file):
            os.remove(HoaxShell_Implants_Logger.generated_implants_file)
    except:
        return False
    return True


if not os.path.exists(main_meta_folder):
    try:
        os.makedirs(main_meta_folder)
    except Exception:
        pass
