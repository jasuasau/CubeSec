#!/usr/bin/env python3
#
# Author: Panagiotis Chartas (t3l3machus)
#
# This script is part of the "Villain C2 Framework":
# https://github.com/t3l3machus/Villain
#
# Patched per second audit: NEW BUG 3 (print_table header mutation) fixed.

import sys, string, base64, os, re, traceback, socket
import netifaces as ni
from random import randint, choice, randrange
from threading import Thread, enumerate as enumerate_threads
from subprocess import check_output
from platform import system as get_system_type

try:
    from Cryptodome.Cipher import AES
except ImportError:
    from Crypto.Cipher import AES

from uuid import UUID, uuid4
from ipaddress import ip_address
from copy import deepcopy
from time import sleep, time
from pyperclip import copy as copy2cb
from string import ascii_uppercase, ascii_lowercase, digits
from importlib import import_module
from datetime import date, datetime

system_type = get_system_type()

try:
    import readline as global_readline
except ImportError:
    try:
        import gnureadline as global_readline
    except ImportError:
        class _ReadlineStub:
            @staticmethod
            def get_line_buffer():
                return ''
            @staticmethod
            def insert_text(_):
                return
            @staticmethod
            def set_completer(_):
                return
            @staticmethod
            def set_completer_delims(_):
                return
            @staticmethod
            def parse_and_bind(_):
                return
            @staticmethod
            def get_endidx():
                return 0
        global_readline = _ReadlineStub()


''' Colors '''
MAIN = '\001\033[38;5;85m\002'
GREEN = '\001\033[38;5;82m\002'
GRAY = PLOAD = '\001\033[38;5;246m\002'
NAME = '\001\033[38;5;228m\002'
RED = '\001\033[1;31m\002'
FAIL = '\001\033[1;91m\002'
ORANGE = '\001\033[0;38;5;214m\002'
LRED = '\001\033[0;38;5;196m\002'
BOLD = '\001\033[1m\002'
PURPLE = '\001\033[0;38;5;141m\002'
BLUE = '\001\033[0;38;5;12m\002'
UNDERLINE = '\001\033[4m\002'
UNSTABLE = '\001\033[5m\002'
END = '\001\033[0m\002'


''' MSG Prefixes '''
INFO = f'{MAIN}Info{END}'
WARN = f'{ORANGE}Warning{END}'
IMPORTANT = f'{ORANGE}Important{END}'
FAILED = f'{RED}Fail{END}'
ERR = f'{LRED}Error{END}'
DEBUG = f'{ORANGE}Debug{END}'
CHAT = f'{BLUE}Chat{END}'
GRN_BUL = f'[{GREEN}*{END}]'
ATT = f'{ORANGE}[!]{END}'
META = '[\001\033[38;5;93m\002M\001\033[38;5;129m\002e\001\033[38;5;165m\002t\001\033[38;5;201m\002a\001\033[0m\002]'

cwd = os.path.dirname(os.path.abspath(__file__))


class Main_prompt:

    original_prompt = prompt = f"{UNDERLINE}Villain{END} > "
    hoax_prompt = None
    ready = True
    SPACE = '#>SPACE$<#'
    exec_active = False

    @staticmethod
    def rst_prompt(prompt=None, prefix='\r'):
        Main_prompt.ready = True
        Main_prompt.exec_active = False
        prompt = prompt if prompt is not None else Main_prompt.prompt
        sys.stdout.write(prefix + prompt + global_readline.get_line_buffer())

    @staticmethod
    def set_main_prompt_ready():
        Main_prompt.exec_active = False
        Main_prompt.ready = True


def exit_with_msg(msg):
    print(f"[{DEBUG}] {msg}")
    sys.exit(0)


def print_fail_and_return_to_prompt(msg):
    print(f'\r[{FAILED}] {msg}')
    Main_prompt.rst_prompt()


def print_shadow(msg):
    print(f'{GRAY}{msg}{END}')


def print_debug(msg):
    print(f'\r[{DEBUG}] {msg}')


def do_nothing():
    pass


def get_datetime():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def get_random_str(length):
    chars = string.ascii_lowercase + string.digits
    return ''.join(choice(chars) for i in range(length))


def get_file_contents(path, mode='rb'):
    try:
        with open(path, mode) as f:
            return f.read()
    except:
        return None


def is_valid_uuid(value):
    try:
        UUID(str(value))
        return True
    except:
        return False


def is_valid_ip(ip_addr):
    try:
        ip_address(ip_addr)
        return True
    except ValueError:
        return False


def parse_lhost(lhost_value):
    try:
        return str(ip_address(lhost_value))
    except ValueError:
        try:
            return ni.ifaddresses(lhost_value)[ni.AF_INET][0]['addr']
        except:
            return False


def print_table(rows, columns):
    columns_list = [list(columns)]

    for item in rows:
        row = dict(item)
        try:
            for key in row.keys():
                item_to_str = str(row[key])
                row[key] = row[key] if len(item_to_str) <= 20 else f"{item_to_str[0:8]}..{item_to_str[-8:]}"
        except:
            pass
        columns_list.append([str(row.get(col, '') if row.get(col) is not None else '') for col in columns])

    col_size = [max(map(len, col)) for col in zip(*columns_list)]
    format_str = '  '.join(["{{:<{}}}".format(i) for i in col_size])
    columns_list.insert(1, ['-' * i for i in col_size])

    for item in columns_list:
        item[-1] = f'{GREEN}{item[-1]}{END}' if item[-1] == 'Active' else item[-1]
        item[-1] = f'{ORANGE}{item[-1]}{END}' if (item[-1] in ['Unreachable', 'Undefined']) else item[-1]
        item[-1] = f'{LRED}{item[-1]}{END}' if (item[-1] in ['Lost']) else item[-1]

        if len(columns_list[0]) >= 2 and columns_list[0][-2] == 'Stability':
            item[-2] = f'{UNSTABLE}{item[-2]} {END}' if item[-2] == 'Unstable' else item[-2]

        print(format_str.format(*item))


def clone_dict_keys(_dict):
    clone = deepcopy(_dict)
    return clone.keys()


def get_terminal_columns():
    try:
        return os.get_terminal_size().columns
    except:
        return 80


def strip_ansi_codes(s):
    s = re.sub('\\[([0-9]+)(;[0-9]+)*m', '', s)
    return re.sub('\033\\[([0-9]+)(;[0-9]+)*m', '', s)


def clean_string(input_string):
    ansi_escape = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
    input_string = ansi_escape.sub('', input_string)
    printable_chars = list(range(0x20, 0x7F)) + [0x09, 0x0A, 0x0D]
    return ''.join(filter(lambda x: ord(x) in printable_chars, input_string))


def ansi_codes_detected(s):
    return True if (re.search('\033\\[([0-9]+)(;[0-9]+)*m', s) or re.search('\\[([0-9]+)(;[0-9]+)*m', s)) else False


def match_regex(regex, data):
    return True if regex.search(data) else False


def split_str_on_regex_index(regex, string):
    match = regex.search(string)
    if not match:
        return [string, '']
    start_index = match.start()
    return [string[0:start_index], string[start_index:]]


def check_list_for_duplicates(l):
    for elem in l:
        if l.count(elem) > 1:
            return True
    return False


def subtract_lists(l1, l2):
    return list(set(l1) - set(l2))


def print_columns(strings):
    columns, _ = os.get_terminal_size()
    mid = (len(strings) + 1) // 2
    max_length1 = max(len(s) for s in strings[:mid])
    max_length2 = max(len(s) for s in strings[mid:])

    if max_length1 + max_length2 + 4 <= columns:
        for i in range(mid):
            col1 = strings[i].ljust(max_length1)
            try:
                col2 = strings[i + mid].ljust(max_length2)
            except:
                col2 = ''
            print(col1 + " " * 4 + col2)
    else:
        max_length = max(len(s) for s in strings)
        for s in strings:
            print(s.ljust(max_length))

    print('\n', end='')


class PrompHelp:

    deprecated = ['exec']
    commands = {

        'connect': {
            'details': f''' 			
Connect with another instance of Villain (sibling server).

connect <IP> <TEAM_SERVER_PORT>''',
            'least_args': 2,
            'max_args': 2
        },

        'generate': {
            'details': f''' 		
Generate a reverse shell command.

generate payload=<OS_TYPE/HANDLER/PAYLOAD_TEMPLATE> lhost=<IP or INTERFACE> [ obfuscate encode ]''',
            'least_args': 0,
            'max_args': 7
        },

        'exec': {
            'details': f''' 			
exec <COMMAND or LOCAL FILE PATH> <SESSION ID or ALIAS>''',
            'least_args': 2,
            'max_args': 2
        },

        'inject': {
            'details': f''' 			
From an active pseudo shell prompt:
inject <LOCAL FILE PATH>''',
            'least_args': 1,
            'max_args': 1,
            'shell': True
        },

        'repair': {
            'details': f''' 			
repair <SESSION ID or ALIAS> <HOSTNAME or USERNAME> <NEW VALUE>''',
            'least_args': 3,
            'max_args': 3
        },

        'shell': {
            'details': f''' 			
shell <SESSION ID or ALIAS>''',
            'least_args': 1,
            'max_args': 1
        },

        'alias': {
            'details': f'''
alias <ALIAS> <SESSION ID>''',
            'least_args': 2,
            'max_args': 2
        },

        'reset': {
            'details': f'''
reset <ALIAS>''',
            'least_args': 1,
            'max_args': 1
        },

        'kill': {
            'details': f'''
kill <SESSION ID or ALIAS>''',
            'least_args': 1,
            'max_args': 1
        },

        'help': {
            'details': f'''Really?''',
            'least_args': 0,
            'max_args': 1
        },

        'siblings': {
            'details': f'''Print info about connected Sibling Servers.''',
            'least_args': 0,
            'max_args': 0
        },

        'threads': {
            'details': f'''Print info about active threads and thread limiter value.''',
            'least_args': 0,
            'max_args': 0
        },

        'sessions': {
            'details': f'''Prints info about active shell sessions.''',
            'least_args': 0,
            'max_args': 0
        },

        'backdoors': {
            'details': f'''Prints specifics about shell and listener types.''',
            'least_args': 0,
            'max_args': 0
        },

        'sockets': {
            'details': f'''Prints Villain related socket services info.''',
            'least_args': 0,
            'max_args': 0
        },

        'id': {
            'details': f'''Print server's unique ID.''',
            'least_args': 0,
            'max_args': 0
        },

        'upload': {
            'details': f'''
From an active pseudo shell prompt:
upload <LOCAL_FILE_PATH> <REMOTE_FILE_PATH>''',
            'least_args': 3,
            'max_args': 3,
            'shell': True
        },

        'cmdinspector': {
            'details': f'''
cmdinspector <ON / OFF>''',
            'least_args': 1,
            'max_args': 1
        },

        'conptyshell': {
            'details': f'''
conptyshell <IP or INTERFACE> <PORT> <SESSION ID or ALIAS>''',
            'least_args': 3,
            'max_args': 3
        },

        'exit': {
            'details': f'''Kill all self-owned sessions and quit.''',
            'least_args': 0,
            'max_args': 0
        },

        'flee': {
            'details': f'''Quit without terminating active sessions.''',
            'least_args': 0,
            'max_args': 0
        },

        'clear': {
            'details': f'''Come on man.''',
            'least_args': 0,
            'max_args': 0
        },

        'purge': {
            'details': f'''Delete all stored sessions metadata.''',
            'least_args': 0,
            'max_args': 0
        },

        'redirectors': {
            'details': f'''
redirectors [pop <ID>]''',
            'least_args': 0,
            'max_args': 2
        },
    }

    @staticmethod
    def print_main_help_msg():
        print(f'''
		\r  Main Prompt
		\r  -----------
		\r  help / connect / generate / siblings / sessions / backdoors / sockets
		\r  redirectors / shell / alias / reset / kill / conptyshell / repair / id
		\r  cmdinspector / threads / clear / purge / flee / exit
		\r
		\r  Pseudo Shell: upload / inject
		\r  For details use: {ORANGE}help <COMMAND>{END}
		''')

    @staticmethod
    def print_detailed(cmd):
        if cmd not in PrompHelp.deprecated:
            PrompHelp.print_justified(PrompHelp.commands[cmd]['details'].strip()) if cmd in PrompHelp.commands.keys() \
                else print(f'No details for command "{cmd}".')
        else:
            print(f'The command "{cmd}" is deprecated.')

    @staticmethod
    def print_justified(text):
        text_length = len(text)
        text_lines = text.split('\n')
        wrapped_text = ''
        term_width = os.get_terminal_size().columns
        term_width_p = 100 if 100 <= term_width else term_width - 2

        if text_length >= term_width_p:
            lines = []
            for p in text_lines:
                if len(p) <= (term_width_p - 3):
                    lines.append('  ' + p + ' ')
                    continue
                words = p.split(' ')
                if words == ['']:
                    continue
                words_s = [w + ' ' for w in words]
                line_length = 0
                count = s = 0
                for w in words_s:
                    line_length += len(w)
                    if line_length < (term_width_p - 3):
                        count += 1
                    else:
                        lines.append('  ' + ' '.join(words[s:count]) + ' ')
                        s = count
                        count += 1
                        line_length = len(w)
                if s < len(words):
                    lines.append(f'  ' + ' '.join(words[s:]) + f' ')
            wrapped_text = '\n'.join(lines)
        else:
            wrapped_text = text
        print('\n' + wrapped_text, end='\n\n')

    @staticmethod
    def validate(cmd, num_of_args):
        valid = True
        if cmd not in PrompHelp.commands.keys():
            print('Unknown command.')
            valid = False
        elif 'shell' in list(PrompHelp.commands[cmd].keys()):
            print(f'You need to be inside a pseudo shell session to use "{cmd}".')
            valid = False
        elif num_of_args < PrompHelp.commands[cmd]['least_args']:
            print('Missing arguments.')
            valid = False
        elif num_of_args > PrompHelp.commands[cmd]['max_args']:
            print('Too many arguments. Use "help <COMMAND>" for details.')
            valid = False
        return valid


bin2shell = {
    'powershell.exe': 'PowerShell',
    'cmd.exe': 'WIN_CMD',
    'unix': 'Unix',
    'zsh': 'Unix'
}

bin2ext = {
    'powershell.exe': '.ps1',
    'cmd.exe': '.bat',
    'unix': '.sh',
    'zsh': '.sh'
}


def multi_set(payload, set_dict):
    for key, val in set_dict.items():
        payload = payload.replace(key, str(val))
    return payload


def validate_host_address(addr):
    addr_verified = False
    try:
        addr_verified = str(ip_address(addr))
    except ValueError:
        try:
            addr_verified = ni.ifaddresses(addr)[ni.AF_INET][0]['addr']
        except:
            if len(addr) > 255:
                return False
            if addr[-1] == ".":
                addr = addr[:-1]
            disallowed = re.compile(r"[^A-Z\d-]", re.IGNORECASE)
            if all(len(part) and not part.startswith("-") and not part.endswith("-") and not disallowed.search(part) for part in addr.split(".")):
                try:
                    socket.gethostbyname(addr)
                    addr_verified = addr
                except:
                    print('Failed to resolve LHOST.')
    return addr_verified


def encrypt_msg(aes_key, msg, iv):
    enc_s = AES.new(aes_key, AES.MODE_CFB, iv)
    if isinstance(msg, bytes):
        cipher_text = enc_s.encrypt(msg)
    else:
        cipher_text = enc_s.encrypt(msg.encode('utf-8'))
    return base64.b64encode(cipher_text)


def decrypt_msg(aes_key, cipher, iv):
    try:
        decryption_suite = AES.new(aes_key, AES.MODE_CFB, iv)
        plain_text = decryption_suite.decrypt(base64.b64decode(cipher + b'=='))
        return plain_text if isinstance(plain_text, str) else plain_text.decode('utf-8', 'ignore')
    except TypeError:
        pass
