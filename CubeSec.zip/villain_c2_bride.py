#!/usr/bin/env python3
# Villain C2 Bridge — integration layer for CubeSec
# Purpose: Export villain_core and settings for cubesec.py direct access
# This module bridges the gap between standalone Villain2.py and embedded C2 in CubeSec

import sys
import os

# Settings defaults for C2 initialization
class C2_Settings:
    """Default C2 runtime settings."""
    version = "2.2.1"

    # Core server config
    core_bind_address = '0.0.0.0'
    core_bind_port = 6501
    core_insecure = False

    # HoaxShell config
    hoax_bind_address = '0.0.0.0'
    hoax_bind_port = 8080
    hoax_bind_port_ssl = 443
    hoax_ssl_support = False
    hoax_certfile = False
    hoax_keyfile = False
    hoax_server_version = 'Apache/2.4.1'

    # Reverse TCP handler config
    reverse_tcp_bind_address = '0.0.0.0'
    reverse_tcp_bind_port = 4443

    # File Smuggler config
    file_smuggler_bind_address = '0.0.0.0'
    file_smuggler_bind_port = 8888

    @staticmethod
    def apply_from_dict(config_dict):
        """Apply custom settings from a config dict."""
        if 'c2_port' in config_dict:
            C2_Settings.core_bind_port = int(config_dict['c2_port'])
        if 'hoax_port' in config_dict:
            C2_Settings.hoax_bind_port = int(config_dict['hoax_port'])
        if 'reverse_tcp_port' in config_dict:
            C2_Settings.reverse_tcp_bind_port = int(config_dict['reverse_tcp_port'])
        if 'file_smuggler_port' in config_dict:
            C2_Settings.file_smuggler_bind_port = int(config_dict['file_smuggler_port'])
        if 'certfile' in config_dict:
            C2_Settings.hoax_certfile = config_dict['certfile']
        if 'keyfile' in config_dict:
            C2_Settings.hoax_keyfile = config_dict['keyfile']
        if 'insecure' in config_dict:
            C2_Settings.core_insecure = config_dict['insecure']


class VillainC2Broker:
    """
    High-level C2 orchestrator.
    Manages initialization, threading, and lifecycle of Villain C2 components.
    """

    def __init__(self):
        self.running = False
        self.payload_gen = None
        self.hoaxshell = None
        self.core_server = None
        self.tcp_handler = None
        self.file_smuggler = None
        self.config = {}

    def init_from_config(self, config_dict):
        """Initialize C2 infrastructure from config dict."""
        C2_Settings.apply_from_dict(config_dict)
        self.config = config_dict
        # Settings applied; components ready for instantiation

    def start_core(self):
        """Start core C2 server."""
        self.running = True
        # Implementation depends on villain_core.py imports
        return {"status": "ready", "port": C2_Settings.core_bind_port}

    def start_hoaxshell(self):
        """Start HoaxShell HTTP/HTTPS beacon handler."""
        # Implementation depends on villain_core.py imports
        return {"status": "ready", "port": C2_Settings.hoax_bind_port}

    def start_reverse_tcp(self):
        """Start reverse TCP multi-handler."""
        # Implementation depends on villain_core.py imports
        return {"status": "ready", "port": C2_Settings.reverse_tcp_bind_port}

    def start_file_smuggler(self):
        """Start file smuggler HTTP server."""
        # Implementation depends on villain_core.py imports
        return {"status": "ready", "port": C2_Settings.file_smuggler_bind_port}

    def start_all(self):
        """Start all C2 services."""
        results = []
        try:
            results.append(("Core", self.start_core()))
            results.append(("HoaxShell", self.start_hoaxshell()))
            results.append(("Reverse TCP", self.start_reverse_tcp()))
            results.append(("File Smuggler", self.start_file_smuggler()))
            self.running = True
        except Exception as e:
            self.running = False
            return {"error": str(e), "results": results}
        return {"status": "all_running", "results": results}

    def stop_all(self):
        """Stop all C2 services."""
        self.running = False
        return {"status": "stopped"}

    def get_status(self):
        """Return current C2 status."""
        return {
            "running": self.running,
            "core_port": C2_Settings.core_bind_port,
            "hoax_port": C2_Settings.hoax_bind_port,
            "reverse_tcp_port": C2_Settings.reverse_tcp_bind_port,
            "file_smuggler_port": C2_Settings.file_smuggler_bind_port,
        }


# Singleton instance
_c2_broker = None

def get_c2_broker():
    """Get or create C2 broker singleton."""
    global _c2_broker
    if _c2_broker is None:
        _c2_broker = VillainC2Broker()
    return _c2_broker


# Export facade functions for easy access from cubesec.py
def init_c2(config_dict):
    """Initialize C2 with config."""
    broker = get_c2_broker()
    broker.init_from_config(config_dict)
    return broker

def start_c2():
    """Start all C2 services."""
    broker = get_c2_broker()
    return broker.start_all()

def stop_c2():
    """Stop all C2 services."""
    broker = get_c2_broker()
    return broker.stop_all()

def get_c2_status():
    """Get C2 status."""
    broker = get_c2_broker()
    return broker.get_status()
